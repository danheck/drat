library(testthat)
library(multinomineq)
test_check("multinomineq")
