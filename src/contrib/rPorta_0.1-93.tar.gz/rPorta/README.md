# RPorta -- PORTA with R interface
Version 0.1

RPorta is a modification of PORTA (http://www.zib.de/Optimization/Software/Porta/). 
RPorta is released under the GNU General Public License.

## Contact

Matthew Gretton, University of Tasmania

See file COPYING for copyright and license information.
