library("testthat")
library("metaBMA")

stopifnot(require("rstan"))

test_check("metaBMA")
